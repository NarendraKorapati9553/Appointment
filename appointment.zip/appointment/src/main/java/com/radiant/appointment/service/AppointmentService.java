package com.radiant.appointment.service;

import org.springframework.stereotype.Service;

import com.radiant.appointment.model.Appointment;

@Service
public interface AppointmentService {
	
	Appointment createOrUpdateAppointment(Appointment appointment);
	
	Appointment getById(Long id);

	Appointment updateAppointmentById(Appointment appointment, Long id);

}
