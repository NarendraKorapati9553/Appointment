package com.radiant.appointment.serviceimpl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.radiant.appointment.constants.AppointmentConstants;
import com.radiant.appointment.model.Appointment;
import com.radiant.appointment.repository.AppointmentRepository;
import com.radiant.appointment.service.AppointmentService;
@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	AppointmentRepository appointmentRepository;

	@Override
	public Appointment createOrUpdateAppointment(Appointment appointment) {
		if(!this.validateBeforeSchedulingAppointment(appointment)) {
			appointment.setAppointmentStatusReasonToUI("No Schedule Available At this time, Please select another");
			return appointment;
		}
		return appointmentRepository.save(appointment);
	}

	@Override
	public Appointment getById(Long id) {
		return appointmentRepository.getById(id);
	}

	public List<Appointment> getByDateAndStatus(Appointment appointment) {
		List<Appointment> existingAppointments = appointmentRepository
				.findByDateTimeAndStatus(appointment.getDateTime(), AppointmentConstants.STATUS_CONFIRMED);
		return existingAppointments;
	}

	@Override
	public Appointment updateAppointmentById(Appointment appointment, Long id) {
		Appointment dbAppointment = appointmentRepository.getById(id);
		if (!ObjectUtils.isEmpty(dbAppointment)) {
			BeanUtils.copyProperties(appointment, dbAppointment);
			if(!this.validateBeforeSchedulingAppointment(appointment)) {
				appointment.setAppointmentStatusReasonToUI("No Schedule Available At this time, Please select another");
				return appointment;
			}
			return appointmentRepository.save(dbAppointment);
		}
		if(!this.validateBeforeSchedulingAppointment(appointment)) {
			appointment.setAppointmentStatusReasonToUI("Unalbe to fetch details from DB");
			return appointment;
		}
		return null;
	}
	
	
	private boolean validateBeforeSchedulingAppointment(Appointment appointment) {
		
		List<Appointment> existingAppointments = appointmentRepository
				.findByDateTimeAndStatus(appointment.getDateTime(), AppointmentConstants.STATUS_CONFIRMED);
		
		if(CollectionUtils.isEmpty(existingAppointments)) {
			return true; //No Appointments got scheduled and book Appointment
		}
		
		return false;
		
		
		
	}

}
