package com.radiant.appointment.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Appointment implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1199047986998805506L;
	
	@Id
	private Long id;
	@Column
	@DateTimeFormat(pattern="yyyy-MM-dd-HH-mm-ss")
	private LocalDateTime dateTime;
	@Column
	private String status;

	private String appointmentStatusReasonToUI;
	
	
	
	
	
	
	
	
	
	
	public String getAppointmentStatusReasonToUI() {
		return appointmentStatusReasonToUI;
	}
	public void setAppointmentStatusReasonToUI(String appointmentStatusReasonToUI) {
		this.appointmentStatusReasonToUI = appointmentStatusReasonToUI;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public LocalDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
