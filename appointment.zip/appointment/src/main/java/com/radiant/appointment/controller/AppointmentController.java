package com.radiant.appointment.controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.radiant.appointment.model.Appointment;
import com.radiant.appointment.service.AppointmentService;

@RestController
@RequestMapping("/api")
public class AppointmentController {
	
	@Autowired
	private AppointmentService appointmentService;
	
	@GetMapping("/test")
	public String test() {
		return "Yes, It is working as expected";
	}
	
	@PostMapping("/appointments")
	public @ResponseBody Appointment createAppointment(@RequestBody Appointment appointment){
		return appointmentService.createOrUpdateAppointment(appointment);
	}
	
	@PutMapping("/appointments/{id}")
	public @ResponseBody Appointment updateAppointmentById(@RequestBody Appointment appointment,@PathParam("id") Long id){
		return appointmentService.updateAppointmentById(appointment, id);
	}
    
}
