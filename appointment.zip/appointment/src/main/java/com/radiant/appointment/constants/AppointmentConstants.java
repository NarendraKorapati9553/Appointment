package com.radiant.appointment.constants;

public final  class AppointmentConstants {
	
   public final static String STATUS_CONFIRMED = "CONFIRMED";
   public final static String STATUS_UNCONFIRMED = "UNCONFIRMED";
   public final static String STATUS_CANCELLED = "CANCELLED";
   public final static String STATUS_COMPLETED = "COMPLETED";
   public final static String STATUS_WAITINGROOM = "WAITINGROOM";
   
}
