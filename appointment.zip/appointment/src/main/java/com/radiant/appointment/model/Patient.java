package com.radiant.appointment.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Patient implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8988561116863730692L;
	@Id
	private Long id;
	@Column
	private String Name;
	@Column
	private String gender;
	@Column
	private boolean newPatient = true;
	@Column
	private int age;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public boolean isNewPatient() {
		return newPatient;
	}
	public void setNewPatient(boolean newPatient) {
		this.newPatient = newPatient;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	

}
