package com.radiant.appointment.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.radiant.appointment.model.Appointment;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long>{
	
	@Query("select a from Appointment a where a.dateTime= :dateTime and a.status= :status")
	List<Appointment> findByDateTimeAndStatus(LocalDateTime dateTime, String status);

}
